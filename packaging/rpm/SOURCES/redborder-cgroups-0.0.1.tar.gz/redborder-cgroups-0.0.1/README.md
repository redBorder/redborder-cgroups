# redborder-cgroups
Configure redborder node with cgroup v2
